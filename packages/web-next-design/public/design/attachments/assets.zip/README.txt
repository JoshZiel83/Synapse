Landing page assets bundle
